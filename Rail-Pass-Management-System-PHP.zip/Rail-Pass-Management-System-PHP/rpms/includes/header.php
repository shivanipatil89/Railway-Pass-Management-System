<div class="top-nav w3-agiletop">
                <div class="container">
                    <div class="navbar-header w3llogo">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>  
                        <h1><a href="index.php">Railway Pass Management System</a></h1> 
                    </div>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <div class="w3menu navbar-right">
                            <ul class="nav navbar">
                                <li><a href="index.php" class="active">Home</a></li>
                                <li><a href="about.php">About</a></li> 
                                                             
                                <li><a href="contact.php">Contact</a></li>
                                <li><a href="download-pass.php">View Pass</a></li>
                                <li><a href="admin/index.php">Admin</a></li>
                            </ul>
                        </div> 
                        <div class="clearfix"> </div>  
                    </div>
                </div>  
            </div>