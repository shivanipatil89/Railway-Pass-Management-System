
	<div class="copy-right"> 
		<div class="container">
			<p>© Railway Pass Management System</p>
		</div> 
	</div> 
	<!-- //footer -->   
	